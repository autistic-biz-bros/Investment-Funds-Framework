We are all brainwashed --> brainwashing can be good or bad --> brainwash yourself to success






You make points in the video is where you propose one proposition is more correct than another.

Which basically means you are forced into perspective.

Now the question is, is one perspective more correct than the other.


where one proposition seems more correct than the other