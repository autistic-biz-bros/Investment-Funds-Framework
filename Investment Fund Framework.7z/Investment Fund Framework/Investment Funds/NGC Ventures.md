Website: https://www.ngc.fund/portfolio

Crunchbase: https://www.crunchbase.com/organization/ngc-ventures/recent_investments/investments

Investments:
- [[Bluzelle]]
- [[Zilliqa]]
- [[Algorand]]
- [[Ankr]]
- [[Oasis Labs]]
- [[Spacemesh]]
- [[Solana]]
- [[Certik]]
- [[Chroma]]
- [[Polkadot]]
- [[Celer]]
- [[Skale]]
- [[Marlin]]
- [[Elrond]]
- [[Kusama]]
- [[Persistence]]
- [[Mina]]

Ecosystem
- [[KuCoin]]
- [[Switcheo Network]]
- [[Nex]]
- [[Babel]]
- [[Dapp Review]]
- [[Tokens/Dekrypt Capital]]
- [[UltrAlpha]]
- [[XChainX]]
- [[dHedge]]
- [[Swingby]]
- [[Kira Network]]
- [[Linear]] $1.8M
- [[Bifrost]] $600K
- [[ForTube]]
- [[Frontier]] $1.9M
- [[Terra Virtua]] $2.5M
- [[Razor]]
- [[Phemex]] $3.5M
- [[Bitwell]]
- [[Polkastarter]] $875K
- [[PlotX]]
- [[Hedget]] $500K
- [[Tidal]] $2M
- [[Ava Labs]] $12M
- [[Sifchain]] $3.5M
- [[Apron]]

Industry Verticals
- [[Standard Tokenization Protocol]]
- [[Hadron]]
- [[Raven Protocol]]
- [[Muzika]]
- [[Top Network]]
- [[Add.xyz]]
- [[Prome0eus]]

Extra
- [[MathWallet]] $12M
- [[O(1) Labs]] $10.9M
- [[Reef Finance]] $3.9M
- [[Banxa]] $2M
- [[Xanpool]]
- [[Vega Protocol]] $10M
- [[Dapix]] $5.7M
- [[Coinflex]] $10M
- [[Xdai]] $500K
- [[Troy Trade]]
- [[Helis]] $500K