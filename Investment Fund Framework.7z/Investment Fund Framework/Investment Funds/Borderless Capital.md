Website: https://borderlesscapital.io/#partners

Crunchbase: https://www.crunchbase.com/organization/algo-capital/recent_investments

Investments:
- [[Securitize]]
- [[IDEX]]
- [[Republic]]
- [[Bosonic]]
- [[Assetblock]]
- [[Internetional Blockchain Monetery Reserve]]
- [[StakerDAO]]
- [[Floating Point Group]]
- [[Humming Bot]]
- [[Climate Trade]]
- [[Blockdaemon]]
- [[Pocket Network]]
- [[Intotheblock]]
- [[Qredo]]
- [[Attestiv]]
- [[OOtoy]]
- [[Props]]
- [[1 World Online]]
- [[Algorand]]