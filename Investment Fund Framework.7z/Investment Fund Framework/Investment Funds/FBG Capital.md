Website: https://www.fbg.capital/

Crunchbase: https://www.crunchbase.com/organization/fbg-capital/recent_investments/investments

Investments:
- [[Oin Finance]] $1M
- [[Hedget]] $500K
- [[Wintermute Trading]]
- [[Sperax]] $6.1M
- [[FTX]] $8M
- [[Dapp.com]] $500K
- [[Neutral Dollar]] $4M
- [[Cartesi]] $500K
- [[ThunderCore]] $50M
- [[Ampleforth]] $1.8M
- [[Aergo]] $60M
- [[Lambda]]
- [[Terra]] $32M
- [[Crescent Crypto Asset Managment]]
- [[Ultrain]] $20M
- [[Nervos]] $28M
- [[BloXroute]]
- [[Republic]] $12M
- [[Cred]] $18M
- [[Coinlist]] $9.2M
- [[Ampleforth]] $3M
- [[Exim]]
- [[Taxa]]
- [[Ren]]$34M
- [[Lino Network]] $20M
- [[Internet Of Services (IOST)]] $40M
- [[Maker]] $12M
- [[NuCypher]] $4.4M
- [[Zilliqa]]
- [[Ripio]] $37M
- [[Stream]] $5M