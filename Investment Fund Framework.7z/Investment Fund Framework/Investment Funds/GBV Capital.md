Website: https://gbv.capital/

Investments:
- [[Serum]]
- [[OmiseGo]]
- [[Bonfida]]
- [[MahaDAO]]
- [[DAO Maker]]
- [[Exeed Me]]
- [[Maps.Me]]
- [[Poolz.finance]]
- [[Linear]]
- [[Chain Guardians]]
- [[Super Farm]]
- [[Paralink]]
- [[Lepricon]]
- [[Dao Ventures]]
-