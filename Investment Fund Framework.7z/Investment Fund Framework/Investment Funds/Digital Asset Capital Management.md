Website: https://dacm.io/portfolio.html

Crunchbase: https://www.crunchbase.com/organization/digital-asset-capital-management/recent_investments

Investments:
- [[Biconomy]] $1.5M
- [[The Graph]]
- [[Ava Labs]]
- [[Akash Network]] $2M
- [[Harmony ONE]]
- [[Kava]]
- [[Algorand]]
- [[ThunderCore]]
- [[CasperLabs]]
- [[Switcheo Network]]
- [[mSTABLE]]
- [[Mina]]
- [[Spacemesh]]
- [[Solana]]