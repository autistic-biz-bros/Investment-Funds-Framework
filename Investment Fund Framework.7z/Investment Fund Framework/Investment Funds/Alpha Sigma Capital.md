Website: https://alphasigma.fund/portfolio/

Crunchbase: https://www.crunchbase.com/organization/alpha-sigma-capital/recent_investments

Investments:
- [[KingSwap]] $20M
- [[ACDX]] $10M
- [[Quant Network]]
- [[ShareRing]]
- [[DigitalBits Project]] $1M
- [[Presearch]]
- [[Carry Protocol]]
- [[Singularity.NET]]
- [[Celcius Network]]
- [[Constellation Labs]]
- [[Emirex]]
- [[Factom]]
- [[Hyprr]]
- [[IDEX]]
- [[Polkadot]]
- [[Solana]]
- [[Uptrennd]]
- [[Tap]]
- [[Airwire]]