Website: https://framework.ventures/

Crunchbase: https://www.crunchbase.com/organization/framework-ventures/recent_investments

Investments:
- [[Aave]] $3M 
- [[Chainlink]]
- [[dHedge]]
- [[DODO]]
- [[Edgeware]]
- [[Fractal]]
- [[Futureswap]] $1M
- [[Kava]]
- [[Pods]]
- [[Primitive]]
- [[Synthetix]] $3.8M
- [[Teller]] $1M
- [[The Graph]] $5.1M
- [[YFI]]
- [[Zapper]] $2M
- [[Powertrade]] $4.7M
- [[Boardroom Labs]] $2.2M
- [[Saddle Finance]] $4.3M 