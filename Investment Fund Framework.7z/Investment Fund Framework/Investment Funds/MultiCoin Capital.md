Website: https://multicoin.capital/portfolio/

Crunchbase: https://www.crunchbase.com/organization/multicoin-capital/company_financials/investments

Investments:
- [[Algorand]]
- [[Alpha Finance Lab]]
- [[Arweave]]
- [[Audius]] $3.1M
- [[Bakkt]]
- [[Dfinity]] $102M
- [[Dfuse]] $3.5M
- [[Dune Analytics]]
- [[Helium]] $15M
- [[Keep]] 
- [[LivePeer]]
- [[MathWallet]] $7.8M
- [[MobileCoin]] 
- [[Near]]
- [[Nervos]] $28M
- [[Perpetual Protocol]] $1.8M
- [[Skale]] $8.9M 
- [[Solana]] $20M
- [[Spring Finance]] $15.8M + $23M
- [[Tagomi]] $12M
- [[Tari]]
- [[Textile]]
- [[The Graph]] $5.1M
- [[Torus]] $2M
- [[Oxio]] $12M + $4.6M
- [[Brain Trust]] $18M
- [[dForce]] $1.5M
- [[Starkware]] $30M
- [[Right Mesh]] $30M
- [[Kadena]] $12M
- [[O(1) Labs]]
- [[Swivel Finance]] $1.2M