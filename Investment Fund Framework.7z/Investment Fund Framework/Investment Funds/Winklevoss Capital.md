Website: https://winklevosscapital.com/portfolio/

Crunchbase: https://www.crunchbase.com/organization/winklevoss-capital/recent_investments/investments

Investments:
- [[BlockFi]]
- [[Earn]]
- [[Gemini]]
- [[Oasis Labs]]
- [[Protocol Labs]]
-  [[Skale]]
-  [[Slingshot]]
-  [[Blockstack (Stacks)]]
-  [[Tezos]]
-  [[Vault12]]
-  [[Zcash]]
-  -[[Filecoin]]
