Website: https://www.dcp.capital/portfolio

Crunchbase: https://www.crunchbase.com/organization/dragonfly-capital-partners-eed4/recent_investments/investments

Investments:
- [[Saddle Finance]] $4.3M
- [[Stablehouse]] $2.2M
- [[CoFix]] $500K
- [[Dune Analytics]] $2M
- [[Sia Coin]] $6.5M
- [[Cozy Finance]] $2M
- [[1inch]] $2.8M
- [[Paradigm]]
- [[Ava Labs]] $12M
- [[Opyn]] $2.2M
- [[Babel]]
- [[Amber Group]] $28M
- [[TaxBit]] $5M
- [[Matter Labs]] $2M
- [[ErisX]] $20M
- [[Tagomi]] $12M
- [[ParaFi Capital]]
- [[Gauntlet]] $2.9M
- [[DYDX]] $10M
- [[Paradigm]]
- [[Lumina]] $4M
- [[Anchorage]]
- [[Bybit]]
- [[Celo]]
- [[Mina]]
- [[Coinmetrics]]
- [[Coinflex]]
- [[Compound]]
- [[Cosmos]]
- [[Crusoe Energy Systems]]
- [[DerivaDEX]]
- [[MobileCoin]]
- [[NUO]]
- [[Oasis Labs]]
- [[Renrenbit]]
- [[Spacemesh]]
- [[UMA]]