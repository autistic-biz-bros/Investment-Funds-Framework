Website: https://jobs.polychain.capital/

Crunchbase: https://www.crunchbase.com/organization/polychain-capital/recent_investments/investments

Investments:
- [[Saddle Finance]]$4.3M
- [[Polymarket]] $4M
- [[Liquidity]] $2.4M
- [[Gauntlet]] $7.3M
- [[Yellow Card]] $1.5M
- [[Acala]] 8.47M
- -[[Merico]] $4.1M
- [[Keeper DAO]]
- [[River Financial]] $5.7M
- [[CoinDCX]] $3M
- [[Horizon Games]]8.8M
- [[StakerDAO]]
- [[Amber Group]] $28M
- [[Crusoe Energy Systems]] $30M
- [[Matrix Port]]
- [[Compound]] $58.2M
- [[Coinflex]] $10M
- [[Altonomy]] $7M
- [[O(1) Labs]] $15M
- [[Celo]] $30M
- [[Dharma]] $7M
- [[Ava Labs]] $6M
- [[Anchorage]] $17M
- [[Coinbase]] $300M
- [[DYDX]] $12M
- [[Paradigm]]
- [[LoanScan]]
- [[Linen]]
- [[MyCrypto]] $4M
- [[Terra]] $32M
- [[Dfinity]] $102M + $61M
- [[Nervos]] $28M
- [[Oasis Labs]] $45M
- [[Haja Network]]
- [[Origo]] $30M
- [[Orchid]] $40M
- [[Basis]] $133M
- [[NuCypher]] $10.7M + $4.4M
- [[Keep]]
- [[Ren]] $34M
- [[Starkware]] $6M
- [[Maker]] $12M
-  [[Polkadot]] $140M
-  [[Kin]] $100M
-  [[Dharma]] $120K