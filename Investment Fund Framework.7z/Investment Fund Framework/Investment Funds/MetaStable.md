Website: https://metastablecapital.com/index.html

Crunchbase: https://www.crunchbase.com/organization/metastable-capital/recent_investments

Investments:
- [[Near]] $40M
- [[Agoric]] $8M
- [[O(1) Labs]] $18.5M
- [[ThunderCore]] $50M
- [[Ava Labs]] $6M
- [[Conflux Foundation]] $35M
- [[Oasis Labs]] $45M
- [[BloXroute]] $1.6M
- [[Orchid]] $36M
- [[Basis]] $133M
- [[Chia]] $3.4M
- [[Starkware]] $6M
- [[Kadena]] $2.3M
- [[Orchid]] $4.7M