Website: http://oneblockcapital.com/

Crunchbase: https://www.crunchbase.com/organization/one-block-capital/recent_investments

Investments:
- [[Zilliqa]]
- [[FTX]] $8M
- [[Quantstamp]]
- [[Tomo Chain]]
- [[Deribit]]
- [[Oasis Labs]] $45M
- [[Marlin]]
- [[Certik]]
- [[Arweave]] $8.7M
- [[Carry Protocol]]
- [[QuarkChain]]
- [[Mainframe]]
- [[Origin]] $28.5M
- [[Fantom]]
- [[OmiseGo]]
- [[Chainlink]]