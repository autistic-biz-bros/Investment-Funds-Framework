Website: https://www.parafi.capital/

Crunchbase: https://www.crunchbase.com/organization/parafi-capital/recent_investments/investments

Investments:
- [[1inch]] $12M
- [[DefiDollar]] $1.2M
- [[Polymarket]] $4M
- [[BarnBridge]] $1M
- [[Acala]] $7M
- [[Ramp Defi]] $1M
- [[deversiFi]] $450K
- [[Uniswap]] $11M
- [[Teller]] $1M
- [[Aave]] $4.5M