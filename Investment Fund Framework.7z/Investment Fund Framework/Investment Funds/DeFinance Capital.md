Website: https://www.defiance.capital/#Portfolio

Crunchbase: https://www.crunchbase.com/organization/defiance-capital-96c1/recent_investments

Investments:
- [[Aave]]
- [[Synthetix]]
- [[SushiSwap]]
- [[DYDX]]
- [[DODO]]
- [[Switcheo Network]]
- [[Switcheo Network]]
- [[Alpha Finance Lab]]
- [[BoringDAO]]
- [[Axie Infinity]]
- [[ACDX]]
- [[Horizon Finance]]
- [[Paraswap]]
- [[InsurAce]]
- [[Swivel Finance]]
- [[Union Finance]]
- [[MetaStable]]
- [[Furucombo]]