Website: https://dekrypt.capital/

Crunchbase: https://www.crunchbase.com/organization/dekrypt-capital/recent_investments/investments

Investment:
- [[Matter Labs]] $2M
- [[Bolt Labs]] $1.5M
- [[Aergo]] $60M
- [[Fluence Labs]]
- [[Nervos]] $28M
- [[Oasis Labs]] $45M
- [[Spacemesh]]
- [[Cred]] $12M
- [[Keep]]
- [[O(1) Labs]]