Website: https://lemniscap.com/portfolio

Crunchbase: https://www.crunchbase.com/organization/lemniscap/recent_investments