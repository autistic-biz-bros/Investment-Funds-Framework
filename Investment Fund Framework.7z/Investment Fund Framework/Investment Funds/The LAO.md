Website: https://www.thelao.io/investments

Crunchbase: https://www.crunchbase.com/organization/the-lao/recent_investments

Investments:
-[[Delta Exchange]]
- [[Dev Protocol]]
- [[Idea Market]]
- [[Boardroom Labs]]
- [[Idle Finance]]
- [[BrightID]]
- [[Swarm]]
- [[PieDAO]]
- [[Aavegotchi]]
- [[Abridged]]
- [[dHedge]]
- [[Transak]]
- [[Gelato Network]] $1.2M
- [[Shell Protocol]]
- [[Pods]]
- [[Ethereum Push Notification Service]] $750K
- [[Zapper]]