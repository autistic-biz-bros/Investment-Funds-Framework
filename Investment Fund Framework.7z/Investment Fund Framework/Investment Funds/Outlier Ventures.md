Website: https://outlierventures.io/portfolio/

Crunchbase:
1. https://www.crunchbase.com/organization/outlier-ventures-ltd-llp/recent_investments/investments
2. https://www.crunchbase.com/organization/outlier-ventures-base-camp/recent_investments/investments

Investments:
- [[Fetch.ai]] $15M
- [[IOTA]]
- [[DIA]]
- [[Ocean Protocol]] $22.1M
- [[Agoric]] $8M
- [[Cryptio]] 
- [[Biconomy]] $1.5M
- [[Nyctale]] €1.1M
- [[KeyTango]]
- [[Gantree]]
- [[Enigma]]
- [[Weaver Labs]]
- [[Swash]]
- [[Cudos]] £2M
- [[Linkdrop]]
- [[Heymate]]
- [[Tracifier]]
- [[Tapmydata]]
- [[OPgames]]
- [[Rexs.io]]
- [[Crucible]]
- [[Bond180]]
- [[Zinc]]
- [[PrimeFlow]]
- [[Fission]]
- [[Data Hop]]
- [[Boson Protocol]] £50K
- [[Haja Network]]
- [[Sovrin]]
- [[Fardoe Software]]
- [[Sperax]] $6.1M
- [[Alkemi]] $565K
- [[Chainlink]]
- [[Seedtoken.io]]
- [[Brave]]
- [[Cosmos]]
- [[Foam]]
- [[Aragon]]