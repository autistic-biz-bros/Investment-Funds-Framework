Website: https://www.hashkeycap.com/

Crunchbase: https://www.crunchbase.com/organization/hashkey-capital/recent_investments/investments

Investments:
- [[Polkadot]]
- [[Blockfolio]]
- [[Platon]] $10M
- [[Cosmos]]
- [[BlockFi]] $30M
- [[Nervos]]
- [[Lightnet]] $31.2M
- [[Mykey]]
- [[ZenGo]]
- [[Harmony ONE]]
- [[Dimension]]
- [[ChainIDE]]
- [[Skale]]
- [[CasperLabs]] $14.5M
- [[Terra]]
- [[Alpha Wallet]]
- [[Commonwealth]]
- [[Linen]] $1M
- [[InfStones]] $34M
- [[1475IFPS]]
- [[Kava]]
- [[Mixmarvel]] $10M
- [[Wootrade]]
- [[IoTeX]]
- [[Darwinia]]
- [[Tassat]]
- [[Hex Trust]]
- [[O(1) Labs]] $10.9M
- [[PureStake]] $1.4M
- [[Brain Trust]]
- [[Zenlink]]
- [[Optium Team]]
- [[StakerDAO]]
- [[BlockFi]] $50M
- [[X-Margin]]
- [[Moonbeam]]
- [[Ava Labs]] $12M
- [[Blockdaemon]] $5.5M
- [[Acala]] $1.4M
- [[The Block]] $13M
- [[Kronos Reaserch]]
- [[Blockstack (Stacks)]]
- [[Blocks.tech]] $11.9M
- [[Longhash Ventures]] CN¥10M
- 