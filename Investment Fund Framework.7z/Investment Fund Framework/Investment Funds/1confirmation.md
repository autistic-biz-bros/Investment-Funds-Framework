Website: https://www.1confirmation.com/portfolio

Crunchbase: https://www.crunchbase.com/organization/1confirmation/recent_investments/investments

Investments:
- [[Polymarket]] $4M
- [[Acala]] $7M
- [[Autherium]] $1.1M
- [[OpenSea]] $2.1M
- [[BloXroute]] $10M
- [[Commonwealth]] $2M
- [[Tendermint]] $9M
- [[Forte]]
- [[Veil]]
- [[DYDX]] $10M
- [[Nervos]] $28M
-  [[OpenSea]] $2M
-  [[Basis]] $133M
-  [[Maker]] $12M
-  [[Notional]]
-  [[SuperRare]]
-  [[Polkadot]]
-  [[Nexus Mutual]]
-  [[Kusama]]
-  [[Cosmos]]
-  [[Augur]]
-  [[Rally]]
-  [[Brave]]
-  [[Edgeware]]
-  [[IRISnet]]