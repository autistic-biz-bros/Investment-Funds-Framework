Website: https://www.threearrowscap.com/select-investments/

Crunchbase: https://www.crunchbase.com/organization/three-arrows-capital/recent_investments

Investments:
- [[O(1) Labs]]
- [[Aave]]
- [[Kyber Network]]
- [[DerivaDEX]]
- [[mSTABLE]]
- [[dHedge]]
- [[Perpetual Protocol]]
- [[Futureswap]]
- [[Synthetix]]
- [[Keeper DAO]]
- [[Mina]]
- [[Polkadot]]

Equity:
- [[BlockFi]]
- [[Deribit]]

Funds:
- [[MultiCoin Capital]]