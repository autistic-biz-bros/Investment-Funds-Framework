website: https://www.gumi-cryptos.com/

Crunchbase: https://www.crunchbase.com/organization/gumi-cryptos/recent_investments

-[[Theta Labs]] $12M
-[[Robot Cache]]
-[[Origin]] $28.5M
- [[Spacemesh]] $15M
- [[Bling]] $3M
- [[Wifi Coin]]
- [[Cloudnado]]
- [[Abe Global]] $3M	
- [[Evercoin]] $1M
- [[financie]] ¥540M
- [[Agoric]] $8M
- [[Keyless]] $2.2M
- [[Coinmine]] $2.5M
- [[OpenSea]] $2.1M
- [[Zenledger]] $3.4M
- [[Vega Protocol]] $10M
- [[Tassat]]
- [[Qredo]]
- [[Xanpool]] $4.3M
- [[Intotheblock]]
- [[Celcius Network]]
- [[Idle Finance]]
- [[1inch]]
- [[Vauld]] $2M