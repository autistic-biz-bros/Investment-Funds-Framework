Website: https://www.electriccapital.com/

Crunchbase: https://www.crunchbase.com/organization/electric-capital/recent_investments/investments

Investments:
- [[Saddle Finance]] $4.3M
- [[Swivel Finance]] $1.2M
- [[Cozy Finance]] $2M
- [[Elrond]] $1.9M
- [[Marlin]] $3M
- [[Near]] $12.1M
- [[O(1) Labs]] $18.5M
- [[ThunderCore]] $50M
- [[Spacemesh]] $15M
- [[Oasis Labs]] $45M
- [[Coinlist]] $9.2M
- [[Anchorage]]
- [[BisonTrails]]
- [[Bitwise]]
- [[Celo]]
- [[Mina]]
- [[Crypto Kitties]]
- [[DerivaDEX]]
- [[Dfinity]]
- [[MobileCoin]]
- [[Zcash]]