Website: https://ventures.beringwaters.com/

Crunchbase: N/A

Investments:
- [[Arweave]]
- [[Synthetix]]
- [[Aave]]
- [[Solana]]
- [[Edgeware]]
- [[Kusama]]
- [[Keep]]
- [[Jarvis]]
- [[Yearn]]
- [[Serum]]
- [[Aragon]]
- [[Union Finance]]